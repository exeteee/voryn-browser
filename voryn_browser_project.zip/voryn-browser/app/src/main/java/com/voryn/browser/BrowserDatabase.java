package com.voryn.browser;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

final class BrowserDatabase extends SQLiteOpenHelper {
    static final class Entry {
        final String title;
        final String url;
        Entry(String title, String url) { this.title = title; this.url = url; }
        @Override public String toString() { return title + "\n" + url; }
    }

    BrowserDatabase(Context context) {
        super(context, "voryn_browser.db", null, 1);
    }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE history (_id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, url TEXT NOT NULL, visited INTEGER NOT NULL)");
        db.execSQL("CREATE INDEX history_visited ON history(visited DESC)");
        db.execSQL("CREATE TABLE bookmarks (_id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, url TEXT NOT NULL UNIQUE, added INTEGER NOT NULL)");
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) { }

    synchronized void addHistory(String title, String url) {
        if (url == null || !(url.startsWith("http://") || url.startsWith("https://"))) return;
        SQLiteDatabase db = getWritableDatabase();
        ContentValues v = new ContentValues();
        v.put("title", title == null || title.isEmpty() ? url : title);
        v.put("url", url);
        v.put("visited", System.currentTimeMillis());
        db.insert("history", null, v);
        db.execSQL("DELETE FROM history WHERE _id NOT IN (SELECT _id FROM history ORDER BY visited DESC LIMIT 1200)");
    }

    synchronized boolean addBookmark(String title, String url) {
        if (url == null || !(url.startsWith("http://") || url.startsWith("https://"))) return false;
        ContentValues v = new ContentValues();
        v.put("title", title == null || title.isEmpty() ? url : title);
        v.put("url", url);
        v.put("added", System.currentTimeMillis());
        return getWritableDatabase().insertWithOnConflict("bookmarks", null, v, SQLiteDatabase.CONFLICT_REPLACE) != -1;
    }

    synchronized List<Entry> getBookmarks() { return read("SELECT title,url FROM bookmarks ORDER BY added DESC LIMIT 300"); }
    synchronized List<Entry> getHistory() { return read("SELECT title,url FROM history ORDER BY visited DESC LIMIT 300"); }

    private List<Entry> read(String sql) {
        ArrayList<Entry> out = new ArrayList<>();
        try (Cursor c = getReadableDatabase().rawQuery(sql, null)) {
            while (c.moveToNext()) out.add(new Entry(c.getString(0), c.getString(1)));
        }
        return out;
    }

    synchronized void clearHistory() { getWritableDatabase().delete("history", null, null); }
    synchronized void removeBookmark(String url) { getWritableDatabase().delete("bookmarks", "url=?", new String[]{url}); }
}

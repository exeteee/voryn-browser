package com.voryn.browser;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.speech.RecognizerIntent;
import android.text.InputType;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebStorage;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.webkit.Profile;
import androidx.webkit.ProfileStore;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;

import org.json.JSONObject;
import org.json.JSONTokener;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

public class MainActivity extends Activity {
    private static final int REQ_FILE = 4101;
    private static final int REQ_SPEECH = 4102;
    private static final int REQ_SAVE_ARCHIVE = 4103;
    private static final int REQ_LOCATION = 4104;
    private static final int MAX_TABS = 8;

    private static final int BG = Color.rgb(16, 23, 38);
    private static final int PANEL = Color.rgb(26, 36, 56);
    private static final int PANEL_2 = Color.rgb(35, 47, 70);
    private static final int TEXT = Color.rgb(241, 245, 255);
    private static final int MUTED = Color.rgb(153, 169, 195);
    private static final int ACCENT = Color.rgb(109, 141, 255);
    private static final int MINT = Color.rgb(71, 215, 199);

    private final ArrayList<BrowserTab> tabs = new ArrayList<>();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private BrowserDatabase database;
    private LinearLayout root;
    private LinearLayout addressRow;
    private FrameLayout webContainer;
    private EditText addressInput;
    private ProgressBar progressBar;
    private TextView tabCountView;
    private TextView securityView;
    private BrowserTab activeTab;
    private ValueCallback<Uri[]> fileChooserCallback;
    private String pendingArchivePath;
    private GeolocationPermissions.Callback pendingGeoCallback;
    private String pendingGeoOrigin;
    private String privateProfileName;
    private boolean multiProfileSupported;
    private boolean shieldEnabled = true;
    private boolean darkTheme = true;
    private boolean desktopMode = false;
    private String searchEngine = "google";
    private View customView;
    private WebChromeClient.CustomViewCallback customViewCallback;
    private FrameLayout fullscreenContainer;

    private final String[] blockedHosts = new String[]{
            "doubleclick.net", "googlesyndication.com", "googleadservices.com",
            "adservice.google.com", "securepubads.g.doubleclick.net",
            "pagead2.googlesyndication.com", "ads.yahoo.com", "adnxs.com",
            "taboola.com", "outbrain.com", "scorecardresearch.com",
            "facebook.net", "connect.facebook.net", "analytics.tiktok.com",
            "hotjar.com", "mixpanel.com", "segment.io", "clarity.ms"
    };

    private static final class BrowserTab {
        WebView webView;
        String url = "https://voryn.newtab/";
        String title = "Новая вкладка";
        boolean incognito;
        boolean readerShowing;
        String profileName;
        BrowserTab(WebView view, boolean privateTab, String profile) {
            webView = view;
            incognito = privateTab;
            profileName = profile;
        }
    }

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        database = new BrowserDatabase(this);
        SharedPreferences p = getSharedPreferences("voryn", MODE_PRIVATE);
        shieldEnabled = p.getBoolean("shield", true);
        darkTheme = p.getBoolean("dark", true);
        desktopMode = p.getBoolean("desktop", false);
        searchEngine = p.getString("search_engine", "google");
        try { multiProfileSupported = WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE); }
        catch (Throwable ignored) { multiProfileSupported = false; }
        cleanupStalePrivateProfiles();
        buildInterface();
        String last = p.getString("last_url", "https://voryn.newtab/");
        newTab(false, last, true);
    }

    private void buildInterface() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        setContentView(root);

        addressRow = new LinearLayout(this);
        addressRow.setGravity(Gravity.CENTER_VERTICAL);
        addressRow.setPadding(dp(10), dp(9), dp(10), dp(5));
        root.addView(addressRow, new LinearLayout.LayoutParams(-1, dp(62)));

        securityView = new TextView(this);
        securityView.setText("◈");
        securityView.setTextColor(MINT);
        securityView.setTextSize(20);
        securityView.setGravity(Gravity.CENTER);
        addressRow.addView(securityView, new LinearLayout.LayoutParams(dp(30), dp(42)));

        addressInput = new EditText(this);
        addressInput.setSingleLine(true);
        addressInput.setTextSize(15);
        addressInput.setTextColor(TEXT);
        addressInput.setHintTextColor(MUTED);
        addressInput.setHint("Поиск или адрес сайта");
        addressInput.setPadding(dp(13), 0, dp(8), 0);
        addressInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        addressInput.setImeOptions(EditorInfo.IME_ACTION_GO);
        addressInput.setBackground(roundRect(PANEL_2, 18));
        addressRow.addView(addressInput, new LinearLayout.LayoutParams(0, dp(43), 1));
        addressInput.setOnFocusChangeListener((v, hasFocus) -> {
            if (hasFocus && activeTab != null) {
                String u = activeTab.url;
                if (u != null && !u.startsWith("https://voryn.newtab/")) addressInput.selectAll();
            }
        });
        addressInput.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_GO || actionId == EditorInfo.IME_ACTION_SEARCH ||
                    (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                navigateFromInput(addressInput.getText().toString());
                return true;
            }
            return false;
        });

        TextView mic = iconButton("🎙", "Голосовой поиск");
        addressRow.addView(mic, new LinearLayout.LayoutParams(dp(40), dp(43)));
        mic.setOnClickListener(v -> startVoiceSearch());
        TextView menu = iconButton("⋮", "Меню");
        addressRow.addView(menu, new LinearLayout.LayoutParams(dp(38), dp(43)));
        menu.setOnClickListener(v -> showMainMenu());

        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);
        progressBar.setProgressTintList(android.content.res.ColorStateList.valueOf(ACCENT));
        progressBar.setIndeterminateTintList(android.content.res.ColorStateList.valueOf(ACCENT));
        root.addView(progressBar, new LinearLayout.LayoutParams(-1, dp(2)));

        webContainer = new FrameLayout(this);
        root.addView(webContainer, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout bottom = new LinearLayout(this);
        bottom.setGravity(Gravity.CENTER);
        bottom.setPadding(dp(6), dp(4), dp(6), dp(6));
        bottom.setBackgroundColor(BG);
        root.addView(bottom, new LinearLayout.LayoutParams(-1, dp(58)));
        addBottomButton(bottom, "‹", "Назад", this::goBack);
        addBottomButton(bottom, "›", "Вперёд", this::goForward);
        addBottomButton(bottom, "+", "Новая вкладка", () -> newTab(false, null, true));
        addBottomButton(bottom, "▣", "Вкладки", this::showTabs);
        tabCountView = (TextView) bottom.getChildAt(3).findViewWithTag("label");
        applyAppTheme();
    }

    private void applyAppTheme() {
        int background = darkTheme ? BG : Color.rgb(246, 248, 252);
        int panel = darkTheme ? PANEL : Color.rgb(232, 237, 245);
        int text = darkTheme ? TEXT : Color.rgb(26, 36, 56);
        int muted = darkTheme ? MUTED : Color.rgb(92, 106, 129);
        root.setBackgroundColor(background);
        addressRow.setBackgroundColor(background);
        addressInput.setTextColor(text);
        addressInput.setHintTextColor(muted);
        addressInput.setBackground(roundRect(panel, 18));
        View bottom = root.getChildAt(root.getChildCount() - 1);
        bottom.setBackgroundColor(background);
        if (bottom instanceof LinearLayout) {
            LinearLayout nav = (LinearLayout) bottom;
            for (int i = 0; i < nav.getChildCount(); i++) {
                View item = nav.getChildAt(i);
                if (item instanceof LinearLayout) {
                    LinearLayout col = (LinearLayout) item;
                    for (int j = 0; j < col.getChildCount(); j++) {
                        if (col.getChildAt(j) instanceof TextView) {
                            TextView t = (TextView) col.getChildAt(j);
                            t.setTextColor(j == 0 ? text : muted);
                        }
                    }
                }
            }
        }
    }

    private void addBottomButton(LinearLayout parent, String symbol, String label, Runnable action) {
        LinearLayout item = new LinearLayout(this);
        item.setOrientation(LinearLayout.VERTICAL);
        item.setGravity(Gravity.CENTER);
        item.setTag(label);
        TextView icon = new TextView(this);
        icon.setText(symbol);
        icon.setTextColor(TEXT);
        icon.setTextSize(22);
        icon.setGravity(Gravity.CENTER);
        item.addView(icon, new LinearLayout.LayoutParams(-1, dp(29)));
        TextView caption = new TextView(this);
        caption.setTag("label");
        caption.setText(label);
        caption.setTextColor(MUTED);
        caption.setTextSize(10);
        caption.setGravity(Gravity.CENTER);
        item.addView(caption, new LinearLayout.LayoutParams(-1, dp(16)));
        parent.addView(item, new LinearLayout.LayoutParams(0, -1, 1));
        item.setOnClickListener(v -> action.run());
    }

    private TextView iconButton(String glyph, String description) {
        TextView button = new TextView(this);
        button.setText(glyph);
        button.setContentDescription(description);
        button.setTextColor(TEXT);
        button.setTextSize(21);
        button.setGravity(Gravity.CENTER);
        button.setBackground(roundRect(PANEL, 14));
        button.setClickable(true);
        button.setFocusable(true);
        return button;
    }

    private void cleanupStalePrivateProfiles() {
        if (!multiProfileSupported) return;
        try {
            ProfileStore store = ProfileStore.getInstance();
            for (String name : new ArrayList<>(store.getAllProfileNames())) {
                if (name != null && name.startsWith("voryn_private_")) store.deleteProfile(name);
            }
        } catch (Throwable ignored) { }
    }

    private void newTab(boolean incognito, String initialUrl, boolean makeActive) {
        if (tabs.size() >= MAX_TABS) {
            toast("Достигнут лимит вкладок для экономии памяти (" + MAX_TABS + ")");
            return;
        }
        if (incognito && !multiProfileSupported) {
            new AlertDialog.Builder(this).setTitle("Приватный режим недоступен")
                    .setMessage("Системный Android WebView на этом устройстве не поддерживает изолированные профили. Чтобы не обещать ложную приватность, Voryn не откроет приватную вкладку.")
                    .setPositiveButton("Понятно", null).show();
            return;
        }
        WebView web = new WebView(this);
        String profile = null;
        if (incognito) {
            if (privateProfileName == null) privateProfileName = "voryn_private_" + System.currentTimeMillis();
            profile = privateProfileName;
            try { WebViewCompat.setProfile(web, profile); }
            catch (Throwable e) {
                web.destroy();
                toast("Не удалось создать изолированный профиль приватного режима");
                return;
            }
        }
        BrowserTab tab = new BrowserTab(web, incognito, profile);
        tabs.add(tab);
        configureWebView(tab);
        webContainer.addView(web, new FrameLayout.LayoutParams(-1, -1));
        if (makeActive) activateTab(tab);
        String target = initialUrl == null || initialUrl.trim().isEmpty() ? "https://voryn.newtab/" : initialUrl;
        if (isHomeUrl(target)) loadHome(tab); else web.loadUrl(target);
    }

    private boolean isHomeUrl(String url) { return url == null || url.isEmpty() || url.startsWith("https://voryn.newtab/"); }

    private void loadHome(BrowserTab tab) {
        tab.url = "https://voryn.newtab/";
        tab.title = "Voryn — новая вкладка";
        String html = "<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1'><meta charset='utf-8'><style>" +
                "*{box-sizing:border-box}body{margin:0;background:#101726;color:#f1f5ff;font-family:Arial,sans-serif;display:flex;min-height:100vh;align-items:center;justify-content:center}" +
                ".wrap{width:100%;max-width:520px;padding:28px}.logo{font-size:42px;font-weight:800;letter-spacing:-2px;color:#f1f5ff}.logo span{color:#47d7c7}.sub{color:#9aaac2;margin:8px 0 28px}.search{display:flex;background:#232f46;border-radius:18px;padding:6px;border:1px solid #354664}.search input{min-width:0;flex:1;border:0;outline:0;color:#fff;background:transparent;padding:13px;font-size:16px}.search button{border:0;background:#6d8dff;color:white;border-radius:13px;padding:0 16px;font-weight:bold}.grid{display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin-top:24px}.tile{background:#1a2438;border:1px solid #2b3b58;border-radius:15px;padding:16px 8px;text-align:center;color:#dce6ff;text-decoration:none;font-size:13px}.tile b{display:block;font-size:22px;margin-bottom:7px;color:#47d7c7}.hint{color:#71829e;font-size:12px;margin-top:26px;line-height:1.6}</style></head><body><div class='wrap'><div class='logo'>voryn<span>.</span></div><div class='sub'>Интернет — без лишнего шума.</div><form class='search' onsubmit='event.preventDefault();go()'><input id='q' autocomplete='off' placeholder='Найти что-нибудь…'><button>Найти</button></form><div class='grid'><a class='tile' href='https://www.youtube.com'><b>▶</b>YouTube</a><a class='tile' href='https://wikipedia.org'><b>◈</b>Wikipedia</a><a class='tile' href='https://reddit.com'><b>◉</b>Reddit</a><a class='tile' href='https://github.com'><b>⌘</b>GitHub</a><a class='tile' href='https://translate.google.com'><b>文</b>Перевод</a><a class='tile' href='https://duckduckgo.com'><b>⌕</b>DuckDuckGo</a></div><div class='hint'>Команды в адресной строке: <b>@tabs</b> · <b>@history</b> · <b>@bookmarks</b> · <b>calc 125*8</b> · <b>!yt котики</b></div></div><script>function go(){let q=document.getElementById('q').value.trim();if(q)location.href='" + searchBase() + "'+encodeURIComponent(q)}</script></body></html>";
        tab.webView.loadDataWithBaseURL("https://voryn.newtab/", html, "text/html", "UTF-8", null);
        tab.title = "Voryn — новая вкладка";
        tab.url = "https://voryn.newtab/";
        updateAddressBar();
    }

    private void configureWebView(BrowserTab tab) {
        WebView web = tab.webView;
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setLoadsImagesAutomatically(true);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setSupportMultipleWindows(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(desktopMode);
        if (Build.VERSION.SDK_INT >= 26) {
            try { s.setSafeBrowsingEnabled(true); } catch (Throwable ignored) { }
        }
        applyDesktopMode(web, desktopMode);
        web.setBackgroundColor(Color.WHITE);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        web.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        web.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) ->
                enqueueDownload(tab, url, userAgent, contentDisposition, mimeType));

        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase(Locale.ROOT);
                if ("http".equals(scheme) || "https".equals(scheme)) return false;
                openExternal(uri.toString());
                return true;
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                Uri uri = Uri.parse(url);
                String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase(Locale.ROOT);
                if ("http".equals(scheme) || "https".equals(scheme)) return false;
                openExternal(url);
                return true;
            }
            @Override public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                tab.url = url;
                tab.readerShowing = false;
                if (tab == activeTab) {
                    progressBar.setVisibility(View.VISIBLE);
                    progressBar.setProgress(5);
                    updateAddressBar();
                }
            }
            @Override public void onPageFinished(WebView view, String url) {
                tab.url = url;
                String title = view.getTitle();
                if (title != null && !title.trim().isEmpty()) tab.title = title;
                if (!tab.incognito && !url.startsWith("https://voryn.newtab/")) database.addHistory(tab.title, url);
                if (tab == activeTab) {
                    progressBar.setProgress(100);
                    handler.postDelayed(() -> { if (activeTab == tab) progressBar.setVisibility(View.INVISIBLE); }, 250);
                    updateAddressBar();
                    updateSecurityIndicator();
                }
            }
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                if (shieldEnabled && isBlockedHost(request.getUrl().getHost())) {
                    return new WebResourceResponse("text/plain", "utf-8", new ByteArrayInputStream(new byte[0]));
                }
                return super.shouldInterceptRequest(view, request);
            }
            @Override public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame() && tab == activeTab) toast("Не удалось загрузить страницу. Проверьте соединение.");
            }
            @Override public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
                runOnUiThread(() -> {
                    if (tabs.contains(tab)) {
                        webContainer.removeView(tab.webView);
                        tabs.remove(tab);
                        try { tab.webView.destroy(); } catch (Throwable ignored) { }
                        if (tabs.isEmpty()) newTab(false, null, true);
                        else activateTab(tabs.get(Math.max(0, tabs.size() - 1)));
                        cleanupPrivateProfileIfUnused();
                        toast("Вкладка перезапущена после сбоя веб-движка");
                    }
                });
                return true;
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view, int newProgress) {
                if (tab == activeTab) {
                    progressBar.setProgress(newProgress);
                    progressBar.setVisibility(newProgress >= 100 ? View.INVISIBLE : View.VISIBLE);
                }
            }
            @Override public void onReceivedTitle(WebView view, String title) {
                if (title != null && !title.isEmpty()) tab.title = title;
            }
            @Override public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileChooserCallback != null) fileChooserCallback.onReceiveValue(null);
                fileChooserCallback = callback;
                try {
                    Intent intent = params.createIntent();
                    startActivityForResult(intent, REQ_FILE);
                    return true;
                } catch (ActivityNotFoundException e) {
                    fileChooserCallback = null;
                    callback.onReceiveValue(null);
                    toast("Не найден системный выбор файлов");
                    return false;
                }
            }
            @Override public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                new AlertDialog.Builder(MainActivity.this).setTitle("Доступ к местоположению")
                        .setMessage("Сайт " + origin + " запрашивает ваше местоположение. Разрешайте доступ только доверенным сайтам.")
                        .setPositiveButton("Продолжить", (d, w) -> {
                            if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                                pendingGeoCallback = callback;
                                pendingGeoOrigin = origin;
                                requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOCATION);
                            } else callback.invoke(origin, true, false);
                        })
                        .setNegativeButton("Запретить", (d, w) -> callback.invoke(origin, false, false)).show();
            }
            @Override public void onPermissionRequest(android.webkit.PermissionRequest request) {
                // Camera/microphone are denied by default. A later release can add an explicit per-origin permission flow.
                request.deny();
            }
            @Override public void onShowCustomView(View view, CustomViewCallback callback) {
                if (customView != null) { callback.onCustomViewHidden(); return; }
                customView = view;
                customViewCallback = callback;
                fullscreenContainer = new FrameLayout(MainActivity.this);
                fullscreenContainer.setBackgroundColor(Color.BLACK);
                fullscreenContainer.addView(view, new FrameLayout.LayoutParams(-1, -1));
                addContentView(fullscreenContainer, new ViewGroup.LayoutParams(-1, -1));
                root.setVisibility(View.GONE);
                getWindow().getDecorView().setSystemUiVisibility(5894 | 1024 | 512);
            }
            @Override public void onHideCustomView() { hideCustomView(); }
        });

        web.setOnLongClickListener(v -> {
            WebView.HitTestResult hit = web.getHitTestResult();
            if (hit != null && (hit.getType() == WebView.HitTestResult.SRC_ANCHOR_TYPE || hit.getType() == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE)) {
                String link = hit.getExtra();
                if (link != null) {
                    new AlertDialog.Builder(MainActivity.this).setTitle("Ссылка")
                            .setItems(new String[]{"Открыть в новой вкладке", "Поделиться ссылкой", "Скопировать ссылку"}, (d, which) -> {
                                if (which == 0) newTab(tab.incognito, link, true);
                                else if (which == 1) shareText(link);
                                else copyText(link);
                            }).show();
                    return true;
                }
            }
            return false;
        });
    }

    private void activateTab(BrowserTab tab) {
        if (tab == null || !tabs.contains(tab)) return;
        activeTab = tab;
        for (BrowserTab t : tabs) t.webView.setVisibility(t == tab ? View.VISIBLE : View.GONE);
        updateAddressBar();
        updateSecurityIndicator();
        if (tabCountView != null) tabCountView.setText("" + tabs.size());
        progressBar.setVisibility(View.INVISIBLE);
    }

    private void updateAddressBar() {
        if (addressInput == null || activeTab == null) return;
        if (!addressInput.hasFocus()) {
            String u = activeTab.url;
            addressInput.setText(isHomeUrl(u) ? "" : u);
            addressInput.setSelection(addressInput.length());
        }
    }

    private void updateSecurityIndicator() {
        if (securityView == null || activeTab == null) return;
        if (activeTab.incognito) {
            securityView.setText("◐"); securityView.setTextColor(ACCENT);
        } else if (activeTab.url != null && activeTab.url.startsWith("https://")) {
            securityView.setText("◈"); securityView.setTextColor(MINT);
        } else {
            securityView.setText("!"); securityView.setTextColor(0xFFFFB36B);
        }
    }

    private void navigateFromInput(String raw) {
        if (activeTab == null) newTab(false, null, true);
        String value = raw == null ? "" : raw.trim();
        if (value.isEmpty()) return;
        ((InputMethodManager) getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(addressInput.getWindowToken(), 0);
        addressInput.clearFocus();

        String lower = value.toLowerCase(Locale.ROOT);
        if (lower.equals("@tabs")) { showTabs(); return; }
        if (lower.equals("@history")) { showHistory(); return; }
        if (lower.equals("@bookmarks")) { showBookmarks(); return; }
        if (lower.equals("@downloads")) { openDownloads(); return; }
        if (lower.equals("@settings")) { showSettings(); return; }
        if (lower.startsWith("calc ")) {
            String expression = value.substring(5).trim();
            try {
                double result = ExpressionEvaluator.evaluate(expression);
                showResult("Результат", expression + " = " + result);
            } catch (Exception e) { toast("Не удалось вычислить выражение"); }
            return;
        }
        if (lower.startsWith("!yt ")) { searchUrl("https://www.youtube.com/results?search_query=", value.substring(4)); return; }
        if (lower.startsWith("!w ")) { searchUrl("https://ru.wikipedia.org/w/index.php?search=", value.substring(3)); return; }
        if (lower.startsWith("!d ")) { searchUrl("https://duckduckgo.com/?q=", value.substring(3)); return; }

        String target = resolveInput(value);
        activeTab.webView.loadUrl(target);
    }

    private void searchUrl(String base, String query) {
        try { activeTab.webView.loadUrl(base + URLEncoder.encode(query, "UTF-8")); }
        catch (Exception e) { toast("Ошибка поиска"); }
    }

    private String resolveInput(String value) {
        if (value.matches("(?i)^https?://.*")) return value;
        if (value.startsWith("www.")) return "https://" + value;
        if (!value.contains(" ") && value.matches("(?i)^[a-z0-9.-]+\\.[a-z]{2,}(:[0-9]{1,5})?(/.*)?$")) return "https://" + value;
        try { return "https://www.google.com/search?q=" + URLEncoder.encode(value, "UTF-8"); }
        catch (Exception e) { return "https://www.google.com/"; }
    }

    private void startVoiceSearch() {
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag());
        i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Что ищем?");
        try { startActivityForResult(i, REQ_SPEECH); }
        catch (ActivityNotFoundException e) { toast("Голосовой ввод недоступен на этом устройстве"); }
    }

    private void showTabs() {
        ArrayList<String> labels = new ArrayList<>();
        labels.add("＋  Новая обычная вкладка");
        labels.add("◐  Новая приватная вкладка");
        for (BrowserTab t : tabs) {
            String title = t.title == null || t.title.isEmpty() ? t.url : t.title;
            labels.add((t == activeTab ? "● " : "○ ") + (t.incognito ? "[Приватно] " : "") + trim(title, 34));
        }
        new AlertDialog.Builder(this).setTitle("Вкладки · " + tabs.size() + "/" + MAX_TABS)
                .setItems(labels.toArray(new String[0]), (d, which) -> {
                    if (which == 0) newTab(false, null, true);
                    else if (which == 1) newTab(true, null, true);
                    else activateTab(tabs.get(which - 2));
                }).setNeutralButton("Закрыть текущую", (d, w) -> closeActiveTab()).setNegativeButton("Готово", null).show();
    }

    private void closeActiveTab() {
        if (activeTab == null) return;
        BrowserTab closing = activeTab;
        tabs.remove(closing);
        webContainer.removeView(closing.webView);
        try { closing.webView.stopLoading(); closing.webView.destroy(); } catch (Throwable ignored) { }
        if (tabs.isEmpty()) newTab(false, null, true);
        else activateTab(tabs.get(Math.max(0, tabs.size() - 1)));
        cleanupPrivateProfileIfUnused();
    }

    private void cleanupPrivateProfileIfUnused() {
        boolean any = false;
        for (BrowserTab t : tabs) if (t.incognito) { any = true; break; }
        if (!any && privateProfileName != null && multiProfileSupported) {
            try { ProfileStore.getInstance().deleteProfile(privateProfileName); } catch (Throwable ignored) { }
            privateProfileName = null;
        }
    }

    private void showMainMenu() {
        String[] items = new String[]{
                "Новая вкладка", "Новая приватная вкладка", "Добавить в закладки", "Закладки", "История", "Загрузки",
                "Найти на странице", "Режим чтения", "Сохранить страницу офлайн", "Перевести страницу",
                "Защита от рекламы и трекеров: " + (shieldEnabled ? "ВКЛ" : "ВЫКЛ"),
                "Версия для компьютера: " + (desktopMode ? "ВКЛ" : "ВЫКЛ"),
                "Поделиться", "Закрыть вкладку", "Настройки"
        };
        new AlertDialog.Builder(this).setTitle("Voryn Browser").setItems(items, (d, which) -> {
            switch (which) {
                case 0: newTab(false, null, true); break;
                case 1: newTab(true, null, true); break;
                case 2: addBookmark(); break;
                case 3: showBookmarks(); break;
                case 4: showHistory(); break;
                case 5: openDownloads(); break;
                case 6: findInPage(); break;
                case 7: openReaderMode(); break;
                case 8: savePageOffline(); break;
                case 9: translatePage(); break;
                case 10: shieldEnabled = !shieldEnabled; getSharedPreferences("voryn", MODE_PRIVATE).edit().putBoolean("shield", shieldEnabled).apply(); toast("Защита " + (shieldEnabled ? "включена" : "выключена")); if (activeTab != null) activeTab.webView.reload(); break;
                case 11: desktopMode = !desktopMode; getSharedPreferences("voryn", MODE_PRIVATE).edit().putBoolean("desktop", desktopMode).apply(); applyDesktopMode(activeTab.webView, desktopMode); activeTab.webView.reload(); break;
                case 12: if (activeTab != null) shareText(activeTab.url); break;
                case 13: closeActiveTab(); break;
                case 14: showSettings(); break;
            }
        }).show();
    }

    private void showSettings() {
        String[] items = new String[]{
                "Тёмная тема: " + (darkTheme ? "ВКЛ" : "ВЫКЛ"),
                "Поисковик: " + searchEngine.toUpperCase(Locale.ROOT),
                "Защита от трекеров: " + (shieldEnabled ? "ВКЛ" : "ВЫКЛ"),
                "Очистить историю", "Очистить cookies и кэш", "О браузере"
        };
        new AlertDialog.Builder(this).setTitle("Настройки Voryn").setItems(items, (d, which) -> {
            switch (which) {
                case 0: darkTheme = !darkTheme; getSharedPreferences("voryn", MODE_PRIVATE).edit().putBoolean("dark", darkTheme).apply(); applyAppTheme(); toast("Тема изменена"); break;
                case 1: chooseSearchEngine(); break;
                case 2: shieldEnabled = !shieldEnabled; getSharedPreferences("voryn", MODE_PRIVATE).edit().putBoolean("shield", shieldEnabled).apply(); toast("Защита " + (shieldEnabled ? "включена" : "выключена")); if (activeTab != null) activeTab.webView.reload(); break;
                case 3: new AlertDialog.Builder(this).setMessage("Удалить локальную историю просмотров? Закладки останутся.").setPositiveButton("Удалить", (x, y) -> { database.clearHistory(); toast("История удалена"); }).setNegativeButton("Отмена", null).show(); break;
                case 4: new AlertDialog.Builder(this).setMessage("Очистить cookies, кэш и данные сайтов обычного профиля? Это может завершить ваши сеансы входа.").setPositiveButton("Очистить", (x, y) -> clearBrowserData()).setNegativeButton("Отмена", null).show(); break;
                case 5: showResult("Voryn Browser 1.0", "Быстрый браузер с приватными профилями, локальной защитой от трекеров, режимом чтения и офлайн-сохранением.\n\nСайты открываются через системный Android WebView. Google Sync и расширения Chrome не входят в эту версию."); break;
            }
        }).show();
    }

    private void chooseSearchEngine() {
        String[] names = new String[]{"Google", "DuckDuckGo", "Bing", "Yahoo"};
        String[] ids = new String[]{"google", "duckduckgo", "bing", "yahoo"};
        int selected = Arrays.asList(ids).indexOf(searchEngine);
        new AlertDialog.Builder(this).setTitle("Поисковая система").setSingleChoiceItems(names, Math.max(0, selected), (dialog, which) -> {
            searchEngine = ids[which];
            getSharedPreferences("voryn", MODE_PRIVATE).edit().putString("search_engine", searchEngine).apply();
            dialog.dismiss();
            toast("Поисковик: " + names[which]);
        }).setNegativeButton("Отмена", null).show();
    }

    private String searchBase() {
        switch (searchEngine) {
            case "duckduckgo": return "https://duckduckgo.com/?q=";
            case "bing": return "https://www.bing.com/search?q=";
            case "yahoo": return "https://search.yahoo.com/search?p=";
            default: return "https://www.google.com/search?q=";
        }
    }

    private void showBookmarks() { showSavedList("Закладки", database.getBookmarks(), true); }
    private void showHistory() { showSavedList("История", database.getHistory(), false); }

    private void showSavedList(String title, List<BrowserDatabase.Entry> entries, boolean bookmarks) {
        if (entries.isEmpty()) { toast(bookmarks ? "Закладок пока нет" : "История пуста"); return; }
        String[] labels = new String[entries.size()];
        for (int i = 0; i < entries.size(); i++) labels[i] = trim(entries.get(i).title, 46) + "\n" + trim(entries.get(i).url, 64);
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle(title).setItems(labels, (d, which) -> {
            String url = entries.get(which).url;
            if (activeTab == null) newTab(false, url, true); else activeTab.webView.loadUrl(url);
        }).setNegativeButton("Закрыть", null).create();
        dialog.setOnShowListener(d -> {
            android.widget.ListView list = dialog.getListView();
            list.setOnItemLongClickListener((parent, view, position, id) -> {
                BrowserDatabase.Entry e = entries.get(position);
                new AlertDialog.Builder(this).setMessage(bookmarks ? "Удалить закладку?" : "Открыть эту запись?")
                        .setPositiveButton(bookmarks ? "Удалить" : "Открыть", (x, y) -> {
                            if (bookmarks) { database.removeBookmark(e.url); dialog.dismiss(); showBookmarks(); }
                            else { if (activeTab != null) activeTab.webView.loadUrl(e.url); }
                        }).setNegativeButton("Отмена", null).show();
                return true;
            });
        });
        dialog.show();
    }

    private void addBookmark() {
        if (activeTab == null || activeTab.incognito || activeTab.url == null || isHomeUrl(activeTab.url)) {
            toast("Эту страницу нельзя сохранить в закладки"); return;
        }
        database.addBookmark(activeTab.title, activeTab.url);
        toast("Добавлено в закладки");
    }

    private void findInPage() {
        if (activeTab == null) return;
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setHint("Найти на странице");
        new AlertDialog.Builder(this).setTitle("Поиск по странице").setView(input)
                .setPositiveButton("Найти", (d, w) -> activeTab.webView.findAllAsync(input.getText().toString()))
                .setNeutralButton("Следующее", (d, w) -> activeTab.webView.findNext(true))
                .setNegativeButton("Закрыть", (d, w) -> activeTab.webView.clearMatches()).show();
    }

    private void openReaderMode() {
        if (activeTab == null || isHomeUrl(activeTab.url)) { toast("Откройте статью, чтобы включить режим чтения"); return; }
        BrowserTab tab = activeTab;
        String js = "(function(){var n=document.querySelector('article')||document.querySelector('main')||document.body;var t=(n.innerText||'').slice(0,30000);return encodeURIComponent(JSON.stringify({title:document.title,text:t}));})()";
        tab.webView.evaluateJavascript(js, value -> {
            try {
                String encoded = (String) new JSONTokener(value).nextValue();
                String json = URLDecoder.decode(encoded, "UTF-8");
                JSONObject obj = new JSONObject(json);
                String title = obj.optString("title", tab.title);
                String text = obj.optString("text", "").trim();
                if (text.isEmpty()) { toast("Не удалось извлечь текст страницы"); return; }
                TextView body = new TextView(this);
                body.setText(title + "\n\n" + text);
                body.setTextColor(0xFF222A38);
                body.setTextSize(18);
                body.setLineSpacing(dp(5), 1.08f);
                body.setPadding(dp(22), dp(18), dp(22), dp(28));
                body.setTextIsSelectable(true);
                ScrollView scroll = new ScrollView(this);
                scroll.setBackgroundColor(0xFFF5F1E9);
                scroll.addView(body);
                new AlertDialog.Builder(this).setTitle("Режим чтения · " + title).setView(scroll)
                        .setPositiveButton("Готово", null).setNeutralButton("Поделиться текстом", (d, w) -> shareText(text)).show();
            } catch (Exception e) { toast("Эта страница не поддерживает извлечение текста"); }
        });
    }

    private void savePageOffline() {
        if (activeTab == null || isHomeUrl(activeTab.url)) { toast("Сначала откройте страницу"); return; }
        String base = new File(getCacheDir(), "voryn-page-" + System.currentTimeMillis() + ".mhtml").getAbsolutePath();
        activeTab.webView.saveWebArchive(base, false, path -> {
            if (path == null || path.isEmpty() || !new File(path).exists()) { toast("Не удалось сохранить страницу"); return; }
            pendingArchivePath = path;
            Intent create = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            create.addCategory(Intent.CATEGORY_OPENABLE);
            create.setType("application/x-mimearchive");
            create.putExtra(Intent.EXTRA_TITLE, safeFileName(activeTab.title) + ".mhtml");
            try { startActivityForResult(create, REQ_SAVE_ARCHIVE); }
            catch (ActivityNotFoundException e) { toast("Не найден выбор места сохранения"); }
        });
    }

    private void translatePage() {
        if (activeTab == null || isHomeUrl(activeTab.url)) return;
        try { newTab(false, "https://translate.google.com/translate?sl=auto&tl=ru&u=" + URLEncoder.encode(activeTab.url, "UTF-8"), true); }
        catch (Exception e) { toast("Не удалось открыть переводчик"); }
    }

    private void enqueueDownload(BrowserTab tab, String url, String userAgent, String contentDisposition, String mimeType) {
        try {
            Uri uri = Uri.parse(url);
            DownloadManager.Request request = new DownloadManager.Request(uri);
            String cookie;
            if (tab.incognito && tab.profileName != null && multiProfileSupported) {
                Profile p = WebViewCompat.getProfile(tab.webView);
                cookie = p.getCookieManager().getCookie(url);
            } else cookie = CookieManager.getInstance().getCookie(url);
            if (cookie != null) request.addRequestHeader("Cookie", cookie);
            if (userAgent != null) request.addRequestHeader("User-Agent", userAgent);
            String fileName = guessFileName(url, contentDisposition);
            request.setTitle(fileName);
            request.setDescription("Загрузка через Voryn Browser");
            request.setMimeType(mimeType);
            request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName);
            request.setAllowedOverMetered(true);
            request.setAllowedOverRoaming(false);
            DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
            dm.enqueue(request);
            toast("Загрузка началась: " + fileName);
        } catch (Exception e) { toast("Не удалось начать загрузку"); }
    }

    private String guessFileName(String url, String disposition) {
        String name = null;
        if (disposition != null) {
            java.util.regex.Matcher m = Pattern.compile("filename\\*?=(?:UTF-8''|\\\")?([^;\\\"]+)", Pattern.CASE_INSENSITIVE).matcher(disposition);
            if (m.find()) name = m.group(1).replace("\"", "").trim();
        }
        if (name == null || name.isEmpty()) {
            String path = Uri.parse(url).getLastPathSegment();
            name = path == null || path.isEmpty() ? "download" : path;
        }
        return safeFileName(Uri.decode(name));
    }

    private void openDownloads() {
        try { startActivity(new Intent(DownloadManager.ACTION_VIEW_DOWNLOADS)); }
        catch (Exception e) { toast("Откройте папку Download в файловом менеджере"); }
    }

    private void clearBrowserData() {
        try {
            CookieManager.getInstance().removeAllCookies(null);
            CookieManager.getInstance().flush();
            WebStorage.getInstance().deleteAllData();
            for (BrowserTab t : tabs) if (!t.incognito) t.webView.clearCache(true);
            toast("Cookies и кэш обычного профиля очищены");
        } catch (Exception e) { toast("Не удалось полностью очистить данные"); }
    }

    private void applyDesktopMode(WebView web, boolean enabled) {
        WebSettings s = web.getSettings();
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(enabled);
        if (enabled) {
            String ua = s.getUserAgentString();
            ua = ua.replaceFirst("\\([^)]*\\)", "(X11; Linux x86_64)").replace(" Mobile", "").replace("; wv)", ")");
            s.setUserAgentString(ua);
        } else {
            s.setUserAgentString(WebSettings.getDefaultUserAgent(this));
        }
    }

    private boolean isBlockedHost(String host) {
        if (host == null) return false;
        String h = host.toLowerCase(Locale.ROOT);
        for (String blocked : blockedHosts) if (h.equals(blocked) || h.endsWith("." + blocked)) return true;
        return false;
    }

    private void openExternal(String url) {
        try {
            Intent i;
            if (url.startsWith("intent:")) i = Intent.parseUri(url, Intent.URI_INTENT_SCHEME);
            else i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception e) { toast("Нет приложения для открытия этой ссылки"); }
    }

    private void shareText(String text) {
        if (text == null) return;
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("text/plain");
        i.putExtra(Intent.EXTRA_TEXT, text);
        startActivity(Intent.createChooser(i, "Поделиться"));
    }

    private void copyText(String text) {
        android.content.ClipboardManager cm = (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        cm.setPrimaryClip(android.content.ClipData.newPlainText("Voryn", text));
        toast("Ссылка скопирована");
    }

    private void goBack() {
        if (activeTab != null && activeTab.webView.canGoBack()) activeTab.webView.goBack();
        else if (tabs.size() > 1) closeActiveTab();
        else loadHome(activeTab);
    }
    private void goForward() { if (activeTab != null && activeTab.webView.canGoForward()) activeTab.webView.goForward(); }

    private void hideCustomView() {
        if (customView == null) return;
        try {
            if (fullscreenContainer != null) fullscreenContainer.removeView(customView);
            if (fullscreenContainer != null) ((ViewGroup) fullscreenContainer.getParent()).removeView(fullscreenContainer);
        } catch (Exception ignored) { }
        customView = null;
        fullscreenContainer = null;
        root.setVisibility(View.VISIBLE);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
        if (customViewCallback != null) customViewCallback.onCustomViewHidden();
        customViewCallback = null;
    }

    @Override public void onBackPressed() {
        if (customView != null) { hideCustomView(); return; }
        if (addressInput != null && addressInput.hasFocus()) {
            addressInput.clearFocus();
            ((InputMethodManager) getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(addressInput.getWindowToken(), 0);
            return;
        }
        goBack();
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_LOCATION && pendingGeoCallback != null) {
            boolean granted = false;
            for (int result : grantResults) if (result == PackageManager.PERMISSION_GRANTED) granted = true;
            pendingGeoCallback.invoke(pendingGeoOrigin, granted, false);
            pendingGeoCallback = null;
            pendingGeoOrigin = null;
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_FILE) {
            if (fileChooserCallback != null) {
                Uri[] results = null;
                if (resultCode == RESULT_OK && data != null) {
                    if (data.getClipData() != null) {
                        int n = data.getClipData().getItemCount();
                        results = new Uri[n];
                        for (int i = 0; i < n; i++) results[i] = data.getClipData().getItemAt(i).getUri();
                    } else if (data.getData() != null) results = new Uri[]{data.getData()};
                }
                fileChooserCallback.onReceiveValue(results);
                fileChooserCallback = null;
            }
        } else if (requestCode == REQ_SPEECH && resultCode == RESULT_OK && data != null) {
            ArrayList<String> results = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (results != null && !results.isEmpty()) navigateFromInput(results.get(0));
        } else if (requestCode == REQ_SAVE_ARCHIVE && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri destination = data.getData();
            try (InputStream in = new FileInputStream(pendingArchivePath); OutputStream out = getContentResolver().openOutputStream(destination)) {
                if (out == null) throw new IllegalStateException("Cannot open destination");
                byte[] buffer = new byte[8192];
                int n;
                while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
                out.flush();
                toast("Страница сохранена для офлайн-просмотра");
            } catch (Exception e) { toast("Не удалось скопировать офлайн-страницу"); }
        }
    }

    @Override protected void onPause() {
        super.onPause();
        if (activeTab != null && !activeTab.incognito && activeTab.url != null) {
            getSharedPreferences("voryn", MODE_PRIVATE).edit().putString("last_url", activeTab.url).apply();
        }
        for (BrowserTab t : tabs) t.webView.onPause();
    }

    @Override protected void onResume() {
        super.onResume();
        for (BrowserTab t : tabs) t.webView.onResume();
    }

    @Override protected void onDestroy() {
        for (BrowserTab t : tabs) {
            try { t.webView.stopLoading(); t.webView.destroy(); } catch (Throwable ignored) { }
        }
        tabs.clear();
        if (privateProfileName != null && multiProfileSupported) {
            try { ProfileStore.getInstance().deleteProfile(privateProfileName); } catch (Throwable ignored) { }
        }
        super.onDestroy();
    }

    private void showResult(String title, String message) {
        TextView text = new TextView(this);
        text.setText(message);
        text.setTextColor(TEXT);
        text.setTextSize(16);
        text.setPadding(dp(20), dp(10), dp(20), dp(10));
        new AlertDialog.Builder(this).setTitle(title).setView(text).setPositiveButton("ОК", null).show();
    }

    private void toast(String message) { Toast.makeText(this, message, Toast.LENGTH_SHORT).show(); }
    private int dp(float value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }
    private String trim(String s, int max) { if (s == null) return ""; return s.length() <= max ? s : s.substring(0, Math.max(0, max - 1)) + "…"; }
    private String safeFileName(String s) {
        if (s == null) return "voryn-page";
        String cleaned = s.replaceAll("[\\\\/:*?\"<>|]", "_").trim();
        if (cleaned.isEmpty()) cleaned = "voryn-page";
        return cleaned.length() > 80 ? cleaned.substring(0, 80) : cleaned;
    }

    private GradientDrawable roundRect(int color, int radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        d.setStroke(dp(1), 0xFF30415F);
        return d;
    }

    private static final class ExpressionEvaluator {
        private final String input;
        private int pos = -1, ch;
        private ExpressionEvaluator(String input) { this.input = input; }
        static double evaluate(String input) {
            if (input == null || input.length() > 100) throw new IllegalArgumentException();
            ExpressionEvaluator p = new ExpressionEvaluator(input);
            p.nextChar();
            double x = p.parseExpression();
            if (p.pos < p.input.length()) throw new IllegalArgumentException();
            if (Double.isNaN(x) || Double.isInfinite(x)) throw new IllegalArgumentException();
            return x;
        }
        void nextChar() { ch = (++pos < input.length()) ? input.charAt(pos) : -1; }
        boolean eat(int c) { while (ch == ' ') nextChar(); if (ch == c) { nextChar(); return true; } return false; }
        double parseExpression() { double x = parseTerm(); for (;;) { if (eat('+')) x += parseTerm(); else if (eat('-')) x -= parseTerm(); else return x; } }
        double parseTerm() { double x = parseFactor(); for (;;) { if (eat('*')) x *= parseFactor(); else if (eat('/')) x /= parseFactor(); else if (eat('%')) x %= parseFactor(); else return x; } }
        double parseFactor() {
            if (eat('+')) return parseFactor();
            if (eat('-')) return -parseFactor();
            double x;
            int start = pos;
            if (eat('(')) { x = parseExpression(); if (!eat(')')) throw new IllegalArgumentException(); }
            else if ((ch >= '0' && ch <= '9') || ch == '.') {
                while ((ch >= '0' && ch <= '9') || ch == '.') nextChar();
                x = Double.parseDouble(input.substring(start, pos));
            } else throw new IllegalArgumentException();
            if (eat('^')) x = Math.pow(x, parseFactor());
            return x;
        }
    }
}
